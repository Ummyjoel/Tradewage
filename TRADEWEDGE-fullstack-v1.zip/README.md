# TRADEWEDGE 1.1 — OAuth backend foundation

This version adds a Node/Express backend and Deriv OAuth 2.0 + PKCE flow.

## Setup

1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Register an OAuth 2.0 application in the Deriv developer dashboard.
4. Register the exact redirect URI:
   `http://localhost:3000/auth/deriv/callback`
5. Put the client ID and client secret in `.env`.
6. Run:
   `npm install`
   `npm run dev`
7. Open `http://localhost:3000`.

## Security

- OAuth state and PKCE verifier are kept in the server session.
- The authorization-code exchange happens on the backend.
- Deriv access tokens are kept in the server session and are never embedded in frontend source.
- The current build loads authenticated account information but does NOT enable real-money buy/sell buttons.

## Next production step

After OAuth is tested, add the authenticated WebSocket workflow:
REST OTP -> authenticated demo/real WebSocket -> proposal -> buy -> proposal_open_contract -> optional sell.

Real trading should remain behind explicit account selection, confirmation, server-side validation, audit logging, rate limiting and a clear DEMO/REAL boundary.
