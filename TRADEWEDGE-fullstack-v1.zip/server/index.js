import "dotenv/config";
import express from "express";
import session from "express-session";
import crypto from "crypto";
import path from "path";
import {fileURLToPath} from "url";

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
app.use(express.json());
app.use(session({
  secret:process.env.SESSION_SECRET || "CHANGE_ME",
  resave:false, saveUninitialized:false,
  cookie:{httpOnly:true, sameSite:"lax", secure:process.env.NODE_ENV==="production", maxAge:86400000}
}));

const DERIV_AUTH="https://auth.deriv.com/oauth2/auth";
const DERIV_TOKEN="https://auth.deriv.com/oauth2/token";
const API="https://api.derivws.com";

function b64url(buf){return Buffer.from(buf).toString("base64").replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");}
function random(n=32){return b64url(crypto.randomBytes(n));}
function sha256(s){return crypto.createHash("sha256").update(s).digest();}

app.get("/api/status",(req,res)=>{
  res.json({ok:true, configured:Boolean(process.env.DERIV_CLIENT_ID && process.env.DERIV_CLIENT_SECRET),
    authenticated:Boolean(req.session.deriv?.access_token)});
});

app.get("/auth/deriv",async(req,res)=>{
  if(!process.env.DERIV_CLIENT_ID || !process.env.DERIV_CLIENT_SECRET) return res.status(503).send("Deriv OAuth is not configured. Add DERIV_CLIENT_ID and DERIV_CLIENT_SECRET to .env.");
  const verifier=random(48), state=random(32);
  req.session.oauth={verifier,state};
  const challenge=b64url(sha256(verifier));
  const redirect=process.env.DERIV_REDIRECT_URI;
  const url=new URL(DERIV_AUTH);
  url.searchParams.set("response_type","code");
  url.searchParams.set("client_id",process.env.DERIV_CLIENT_ID);
  url.searchParams.set("redirect_uri",redirect);
  url.searchParams.set("scope","trade account_manage application_read payment");
  url.searchParams.set("state",state);
  url.searchParams.set("code_challenge",challenge);
  url.searchParams.set("code_challenge_method","S256");
  res.redirect(url.toString());
});

app.get("/auth/deriv/callback",async(req,res)=>{
  try{
    const {code,state,error}=req.query;
    if(error) return res.status(400).send(`Deriv authorization failed: ${error}`);
    if(!code || !state || !req.session.oauth || state!==req.session.oauth.state) return res.status(400).send("Invalid OAuth state.");
    const body=new URLSearchParams({
      grant_type:"authorization_code",
      client_id:process.env.DERIV_CLIENT_ID,
      client_secret:process.env.DERIV_CLIENT_SECRET,
      code:String(code),
      code_verifier:req.session.oauth.verifier,
      redirect_uri:process.env.DERIV_REDIRECT_URI
    });
    const r=await fetch(DERIV_TOKEN,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body});
    const data=await r.json();
    if(!r.ok || !data.access_token) return res.status(502).json(data);
    req.session.deriv={access_token:data.access_token,refresh_token:data.refresh_token,expires_at:Date.now()+((data.expires_in||3600)*1000)};
    delete req.session.oauth;
    res.redirect("/");
  }catch(e){res.status(500).send("OAuth callback error.");}
});

app.post("/auth/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

async function derivFetch(req,pathName,opts={}){
  if(!req.session.deriv?.access_token) throw Object.assign(new Error("Not authenticated"),{status:401});
  const headers={...(opts.headers||{}),Authorization:`Bearer ${req.session.deriv.access_token}`};
  return fetch(`${API}${pathName}`,{...opts,headers});
}

app.get("/api/accounts",async(req,res)=>{
  try{
    const r=await derivFetch(req,"/trading/v1/options/accounts");
    const data=await r.json(); res.status(r.status).json(data);
  }catch(e){res.status(e.status||500).json({error:e.message});}
});

app.post("/api/account/:accountId/otp",async(req,res)=>{
  try{
    const r=await derivFetch(req,`/trading/v1/options/accounts/${encodeURIComponent(req.params.accountId)}/otp`,{method:"POST"});
    const data=await r.json(); res.status(r.status).json(data);
  }catch(e){res.status(e.status||500).json({error:e.message});}
});

/*
  The browser can use the short-lived URL returned here to open the
  authenticated demo/real WebSocket. The access token itself never
  reaches the browser.
*/
app.use(express.static(path.join(__dirname,"..")));
app.get("*",(req,res)=>{
  if(req.path.startsWith("/api/")||req.path.startsWith("/auth/")) return res.status(404).end();
  res.sendFile(path.join(__dirname,"..","index.html"));
});

app.listen(process.env.PORT||3000,()=>console.log(`TRADEWEDGE server running on http://localhost:${process.env.PORT||3000}`));