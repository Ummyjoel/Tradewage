import React,{useEffect,useState} from "react";
import {createRoot} from "react-dom/client";
import "./styles.css";

const contracts={
 "Rise/Fall":[["Rise","CALL"],["Fall","PUT"]],
 "Digits":[["Matches","DIGITMATCH"],["Differs","DIGITDIFF"]],
 "Over/Under":[["Over","DIGITOVER"],["Under","DIGITUNDER"],["Even","DIGITEVEN"],["Odd","DIGITODD"]]
};
const symbols=[["Volatility 100 (1s)","1HZ100V"],["Volatility 75 (1s)","1HZ75V"],["Volatility 50 (1s)","1HZ50V"],["Volatility 25 (1s)","1HZ25V"],["Volatility 10 (1s)","1HZ10V"]];

function App(){
 const [market,setMarket]=useState("Rise/Fall"),[contract,setContract]=useState(contracts["Rise/Fall"][0]);
 const [symbol,setSymbol]=useState("1HZ100V"),[price,setPrice]=useState(null),[last,setLast]=useState(null);
 const [auth,setAuth]=useState(false),[configured,setConfigured]=useState(false),[account,setAccount]=useState(null),[notice,setNotice]=useState("");
 const [mode,setMode]=useState("DEMO");

 useEffect(()=>{fetch("/api/status").then(r=>r.json()).then(x=>{setAuth(x.authenticated);setConfigured(x.configured)})},[]);
 useEffect(()=>{
   const ws=new WebSocket("wss://api.derivws.com/trading/v1/options/ws/public");
   ws.onopen=()=>ws.send(JSON.stringify({ticks:symbol,subscribe:1}));
   ws.onmessage=e=>{try{const d=JSON.parse(e.data);if(d.tick){const p=Number(d.tick.quote);setPrice(p);setLast(Number(p.toFixed(d.tick.pip_size??2).replace(".","").slice(-1)))}}catch{}};
   return ()=>ws.close();
 },[symbol]);

 async function login(){
   if(!configured){setNotice("Add your Deriv OAuth client ID/secret to the server .env first.");return}
   location.href="/auth/deriv";
 }
 async function loadAccounts(){
   const r=await fetch("/api/accounts"); const d=await r.json();
   if(!r.ok){setNotice(d.error||"Could not load accounts");return}
   setAccount(d.data?.[0]||d.accounts?.[0]||d);
   setNotice("Deriv account data loaded.");
 }
 return <div className="app">
  <header><div><div className="logo">TW</div><b>TRADEWEDGE</b><small>Options terminal</small></div>
   <div className="actions"><button className={mode==="DEMO"?"sel":""} onClick={()=>setMode("DEMO")}>DEMO</button><button className={mode==="REAL"?"sel real":""} onClick={()=>setMode("REAL")}>REAL</button>{auth?<button onClick={()=>fetch("/auth/logout",{method:"POST"}).then(()=>location.reload())}>Logout</button>:<button onClick={login}>Connect Deriv</button>}</div>
  </header>
  <main>
   <section className="panel">
    <div className="head"><h2>Markets</h2><span className="live">● LIVE</span></div>
    <div className="market">{Object.keys(contracts).map(m=><button className={market===m?"chosen":""} onClick={()=>{setMarket(m);setContract(contracts[m][0])}} key={m}><b>{m}</b><small>{contracts[m].map(x=>x[0]).join(" · ")}</small></button>)}</div>
    <div className="form">
      <label>Symbol<select value={symbol} onChange={e=>setSymbol(e.target.value)}>{symbols.map(x=><option key={x[1]} value={x[1]}>{x[0]}</option>)}</select></label>
      <label>Contract<select value={contract[1]} onChange={e=>setContract(contracts[market].find(x=>x[1]===e.target.value))}>{contracts[market].map(x=><option key={x[1]} value={x[1]}>{x[0]}</option>)}</select></label>
    </div>
    <div className="quote"><div><small>Quote</small><b>{price==null?"—":price.toFixed(2)}</b></div><div><small>Last digit</small><b>{last??"—"}</b></div><div><small>Mode</small><b>{mode}</b></div></div>
    <div className="notice">{notice||"Public market data is connected. Authenticated trading is available only after Deriv authorization."}</div>
   </section>
   <aside className="panel">
    <div className="head"><h2>Account</h2><span>{auth?"CONNECTED":"NOT CONNECTED"}</span></div>
    {auth?<><button className="primary" onClick={loadAccounts}>Load Deriv accounts</button>{account&&<pre>{JSON.stringify(account,null,2)}</pre>}</>:<p className="muted">Connect your Deriv account through OAuth. TRADEWEDGE never asks you to paste your Deriv password into this app.</p>}
    <hr/><small className="muted">Real-money trading is deliberately gated until the authenticated account and trade workflow are configured and tested.</small>
   </aside>
  </main>
  <footer>TRADEWEDGE · secure OAuth foundation · demo/public market data</footer>
 </div>
}
createRoot(document.getElementById("root")).render(<App/>);